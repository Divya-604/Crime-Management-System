-- Create Database
CREATE DATABASE IF NOT EXISTS crime_mgmt;
USE crime_mgmt;

-- Users (Admin, Officer, Civilian)
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    username VARCHAR(100) UNIQUE,
    password VARCHAR(100),
    role ENUM('admin','officer','civilian') DEFAULT 'civilian'
);

-- Crimes
CREATE TABLE crimes (
    crime_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200),
    description TEXT,
    crime_type VARCHAR(100),
    location VARCHAR(150),
    status ENUM('reported','investigating','closed') DEFAULT 'reported',
    reported_by INT,
    report_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reported_by) REFERENCES users(user_id)
);

-- Officers
CREATE TABLE officers (
    officer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    rank VARCHAR(100),
    contact VARCHAR(20),
    assigned_crime INT,
    FOREIGN KEY (assigned_crime) REFERENCES crimes(crime_id)
);

-- Witnesses
CREATE TABLE witnesses (
    witness_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    phone VARCHAR(20),
    statement TEXT,
    crime_id INT,
    FOREIGN KEY (crime_id) REFERENCES crimes(crime_id)
);

-- Simple trigger for log
CREATE TABLE audit_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(50),
    operation VARCHAR(10),
    record_id INT,
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

DELIMITER $$
CREATE TRIGGER trg_after_crime_insert
AFTER INSERT ON crimes
FOR EACH ROW
BEGIN
  INSERT INTO audit_log(table_name, operation, record_id)
  VALUES('crimes','INSERT', NEW.crime_id);
END$$
DELIMITER ;

-- Sample data
INSERT INTO users(name, username, password, role)
VALUES
('Admin User','admin','admin123','admin'),
('Officer Rahul','rahul','rahul123','officer'),
('John Doe','john','john123','civilian');

INSERT INTO crimes(title, description, crime_type, location, reported_by)
VALUES
('Burglary at Mall','A break-in at city mall','Burglary','City Mall',3),
('Car Theft','A car stolen near railway station','Theft','Station Road',3);
