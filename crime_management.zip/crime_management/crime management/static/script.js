

// 🌟 Crime Management System Frontend JS
console.log("🚓 Crime Management System scripts loaded");

// Smooth page fade-in effect
document.addEventListener("DOMContentLoaded", () => {
  document.body.style.opacity = 0;
  document.body.style.transition = "opacity 0.7s ease-in-out";
  setTimeout(() => (document.body.style.opacity = 1), 100);
});

// Confirmation for delete buttons
document.querySelectorAll(".btn-danger").forEach(btn => {
  btn.addEventListener("click", e => {
    const confirmDelete = confirm("Are you sure you want to delete this record?");
    if (!confirmDelete) e.preventDefault();
  });
});

// Navbar scroll effect (optional aesthetic)
window.addEventListener("scroll", () => {
  const navbar = document.que0ySelector(".navbar");
  if (navbar) {
    navbar.style.boxShadow = window.scrollY > 50 ? "0 2px 10px rgba(0,0,0,0.2)" : "none";
  }
});
