from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from mysql.connector import Error

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = "crime_secret_key"

# ---------------- DATABASE CONNECTION ----------------
def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Divya",  # change if your MySQL password differs
            database="crime_mgmt"
        )
        return conn
    except Error as e:
        print("Database connection failed:", e)
        return None

# ---------------- HOME / LOGIN ----------------
@app.route('/', methods=['GET', 'POST'])
def home():
    if 'user_id' in session:
        if session['role'] == 'officer':
            return redirect(url_for('officer_dashboard'))
        else:
            return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        if not conn:
            flash("Database connection failed!", "danger")
            return render_template("login.html")

        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user:
            session['user_id'] = user['user_id']
            session['role'] = user['role']
            session['name'] = user['name']
            flash("Login successful!", "success")
            if user['role'] == 'officer':
                return redirect(url_for('officer_dashboard'))
            else:
                return redirect(url_for('dashboard'))
        else:
            flash("Invalid username or password!", "danger")

    return render_template("login.html")

# ---------------- SIGNUP ----------------
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        username = request.form['username']
        password = request.form['password']
        role = request.form.get('role', 'civilian')

        conn = get_db_connection()
        if not conn:
            flash("Database connection failed!", "danger")
            return render_template("signup.html")

        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username=%s", (username,))
        if cursor.fetchone():
            flash("Username already exists! Please choose another.", "warning")
            cursor.close()
            conn.close()
            return redirect(url_for('signup'))

        cursor.execute(
            "INSERT INTO users (name, username, password, role) VALUES (%s, %s, %s, %s)",
            (name, username, password, role)
        )
        conn.commit()
        cursor.close()
        conn.close()

        flash("Account created successfully! Please log in.", "success")
        return redirect(url_for('home'))

    return render_template("signup.html")

# ---------------- CIVILIAN DASHBOARD ----------------
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash("Please log in first!", "warning")
        return redirect(url_for('home'))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM crimes WHERE reported_by=%s ORDER BY report_date DESC", (session['user_id'],))
    crimes = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template("index.html", crimes=crimes, user=session)

# ---------------- REPORT CRIME ----------------
@app.route('/report', methods=['GET', 'POST'])
def report_crime():
    if 'user_id' not in session:
        flash("Please log in first!", "warning")
        return redirect(url_for('home'))

    if request.method == 'POST':
        title = request.form['title']
        desc = request.form['desc']
        ctype = request.form['ctype']
        loc = request.form['loc']
        reported_by = session['user_id']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO crimes (title, description, crime_type, location, reported_by) VALUES (%s, %s, %s, %s, %s)",
            (title, desc, ctype, loc, reported_by)
        )
        conn.commit()
        cursor.close()
        conn.close()

        flash("Crime reported successfully!", "success")
        return redirect(url_for('dashboard'))

    return render_template("report.html", user=session)

# ---------------- VIEW CRIMES ----------------
@app.route('/view_crime')
def view_crime():
    if 'user_id' not in session:
        flash("Please log in first!", "warning")
        return redirect(url_for('home'))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    if session['role'] == 'officer':
        cursor.execute("SELECT * FROM crimes ORDER BY report_date DESC")
    else:
        cursor.execute("SELECT * FROM crimes WHERE reported_by=%s ORDER BY report_date DESC", (session['user_id'],))
    crimes = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template("view_crime.html", crimes=crimes, user=session)

# ---------------- DELETE CRIME (POST) ----------------
@app.route('/delete_crime/<int:crime_id>', methods=['POST'])
def delete_crime(crime_id):
    if 'user_id' not in session or session['role'] != 'officer':
        flash("Access denied! Officers only.", "danger")
        return redirect(url_for('home'))

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM crimes WHERE crime_id=%s", (crime_id,))
        conn.commit()
        flash("Crime deleted successfully!", "success")
    except Exception as e:
        print("Error deleting record:", e)
        flash("Error deleting record.", "danger")
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for('view_crime'))

# ---------------- VIEW OFFICERS ----------------
@app.route('/view_officers')
def view_officers():
    if session.get('role') != 'officer':
        flash("Access denied! Officers only.", "danger")
        return redirect(url_for('home'))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT user_id, name, username FROM users WHERE role='officer'")
    officers = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template("view_officers.html", officers=officers, user=session)

# ---------------- OFFICER DASHBOARD ----------------
@app.route('/officer_dashboard')
def officer_dashboard():
    if session.get('role') == 'officer':
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM crimes ORDER BY report_date DESC")
        crimes = cursor.fetchall()
        cursor.close()
        conn.close()
        return render_template("officer_dashboard.html", crimes=crimes, user=session)

    flash("Access denied! Officers only.", "danger")
    return redirect(url_for('home'))

# ---------------- LOGOUT ----------------
@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for('home'))

# ---------------- MAIN ----------------
if __name__ == "__main__":
    app.run(debug=True)
